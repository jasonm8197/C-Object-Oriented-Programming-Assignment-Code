#pragma once
#include "Image.h"

class ImageZoom : public Image
{
public:
	//Image scaling
	Image* Scale(Image &image, char* scaleType);
	Image* CreateROI(Image& image, int x1, int y1, int x2, int y2);//Stretch exercise
	void LogImageInfo(const Image &img, const char* filename);
	int scaleSize = 1;
};
