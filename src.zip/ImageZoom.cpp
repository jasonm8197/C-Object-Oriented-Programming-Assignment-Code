#include "ImageZoom.h"
#include <iostream>
#include <fstream>

//Creates a new scaled image
Image* ImageZoom::Scale(Image &image, char* scaleType)
{
	int s = scaleSize;
	int w2 = image.w*s;
	int h2 = image.h*s;
	Image::Data* newPixels = new Image::Data[w2*h2];

	int px, py;


	for (int i = 0; i<h2; i++) {
		for (int j = 0; j<w2; j++) {
			px = j / s;
			py = i / s;
			newPixels[(i*w2) + j] = image.pixels[(int)((py*image.w) + px)];
		}
	}

	Image* img = new Image(w2, h2);
	img->pixels = newPixels;
	return img;
}

//Creates a new image from region of interest
Image* ImageZoom::CreateROI(Image& image, int x1, int y1, int x2, int y2)
{
	int w2, h2;
	w2 = x2 - x1;
	h2 = y2 - y1;
	std::cout << "Region of interest: (" << x1 << "," << y1 << "," << x2 << "," << y2 << ")\n";
	Image::Data* newPixels = new Image::Data[w2*h2];

	std::cout << "Copying image region...\n";
	int px, py;
	for (int px = x1; px < x2; px++)
		for (int py = y1; py < y2; py++)
		{
			newPixels[(px - x1) + w2*(py - y1)] = image.pixels[px + (image.w*py)];
		}

	Image* img = new Image(w2, h2);
	img->pixels = newPixels;
	std::cout << "Successfully created new image.\n";
	return img;
}

//Writes log info to .bin file
void ImageZoom::LogImageInfo(const Image &img, const char* filename)
{
	std::cout << "Writing image info ..." << std::endl;

	std::ofstream ofs;
	try {
		ofs.open(filename, std::ios::binary); // need to spec. binary mode for Windows users 
		if (ofs.fail()) throw("Can't open output file");
		ofs << "Image width: " << img.w << "\nImage Height: " << img.h << "\nImage scale amount: " << scaleSize << "\n";
		ofs.close();
		//Confirm image write
		std::cout << "Image info written" << std::endl;
	}
	catch (const char *err) {
		fprintf(stderr, "%s\n", err);
		ofs.close();
	}
}