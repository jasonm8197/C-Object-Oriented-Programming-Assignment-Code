//main.cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include "Image.h"
#include "ImageZoom.h"
#include <vector>
#include <time.h>

Image* readPPM(const char* file);
void writePPM(const Image &img, const char* file);
Image* AddImage(const char *filename);
double GetTime();

int main()
{
	double before, after;
	std::cout << "************************************" << std::endl;
	std::cout << "Image Stacker / Image Scaler" << std::endl;
	std::cout << "************************************" << std::endl;

	//****************************************************
	//As an example, read one ppm file and write it out to testPPM.ppm
	//We need to specify the dimensions of the image
	//****************************************************

	//Select program
	char in = ' ';
	while (in != '1' && in != '2' && in != '3')
	{
		std::cout << "What would you like to do?\n1. Image Blending\n2. Image scaling\n3. Region of Interest\n" << std::endl;
		std::cin >> in;
	}
	
	//Image blending
	if (in == '1')
	{
		//Load images
		std::cout << "Gathering images for image blending.\n" << std::endl;
		std::vector<const char*> imageFiles;
		int width = 3264, height = 2448;
		int secWidth = 3264, secHeight = 612;
		imageFiles.push_back("Images/ImageStacker_set1/IMG_1.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_2.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_3.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_4.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_5.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_6.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_7.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_8.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_9.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_10.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_11.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_12.ppm");
		imageFiles.push_back("Images/ImageStacker_set1/IMG_13.ppm");

		std::vector<Image*> images;
		for (int i = 0; i < imageFiles.size(); i++)
		{
			images.push_back(AddImage(imageFiles[i]));
		}

		//Select image blend type
		char* blendType = "none";
		in = ' ';
		while (in != '1' && in != '2' && in != '3')
		{
			std::cout << "Select blend type:\n1. Mean blending\n2. Median Blending\n3. Sigma clipping\n" << std::endl;
			std::cin >> in;
		}
		switch (in)
		{
		case '1': {blendType = "mean"; break; }
		case '2': {blendType = "median"; break; }
		case '3': {blendType = "sigmaclip"; break; }
		}

		before = GetTime();
		Image* blendedImage = Image::Blend(images, blendType);
		after = GetTime();
		std::cout << "Time taken: " << after - before << " seconds" << std::endl;

		//Output to file
		writePPM(*blendedImage, "testPPM.ppm");
		blendedImage->LogImageInfo(*blendedImage, "logInfo.bin");
	}

	//Image scaling
	else if (in == '2')
	{
		//Load image
		Image* img = AddImage("Images/Zoom/zIMG_1.ppm");

		//Input scale size
		in = ' ';
		while (in != '2' && in != '3' && in != '4')
		{
			std::cout << "Select scale size:\n2. Scale 2x\n3. Scale 3x\n4. Scale 4x\n" << std::endl;
			std::cin >> in;
		}

		//Zoom object/algorithm
		ImageZoom zoom;
		switch (in)
		{
		case '2': {zoom.scaleSize = 2; break; }
		case '3': {zoom.scaleSize = 3; break; }
		case '4': {zoom.scaleSize = 4; break; }
		}

		before = GetTime();
		std::cout << "Applying image scaling algorithm with scale " << zoom.scaleSize << std::endl;
		Image* scaledImage = zoom.Scale(*img, "nneighbour");
		after = GetTime();
		std::cout << "Time taken: " << after - before << " seconds" << std::endl;

		//Output to file
		writePPM(*scaledImage, "testPPM.ppm");
		zoom.LogImageInfo(*scaledImage, "logInfo.bin");
		
	}

	//Region of interest
	else if (in == '3')
	{
		Image* img = AddImage("Images/ROI/rIMG_1.ppm");
		ImageZoom zoom;

		//Enter co-ordinates
		int x1, y1, x2, y2;
		bool valid = false;
		while (true)
		{
			std::cout << "Please enter valid co-ordinates (x1,y1,x2,y2) for region of interest.\nDimensions of image are " << img->w << "," << img->h << std::endl;
			std::cout << "x1: "; std::cin >> x1; if (x1 < 0 || x1 >= img->w) continue;
			std::cout << "y1: "; std::cin >> y1; if (y1 < 0 || y1 >= img->h) continue;
			std::cout << "x2: "; std::cin >> x2; if (x2 <= x1 || x2 >= img->w) continue;
			std::cout << "y2: "; std::cin >> y2; if (y2 <= y1|| y2 >= img->h) continue;
			break;
		}

		//Create ROI image
		std::cout << "Co-ordinates are valid. Creating cropped image." << std::endl;

		before = GetTime();
		Image* croppedImage = zoom.CreateROI(*img, x1, y1, x2, y2);
		after = GetTime();
		std::cout << "Time taken: " << after - before << " seconds" << std::endl;

		//Output to file
		writePPM(*croppedImage, "testPPM.ppm");
		zoom.LogImageInfo(*croppedImage, "logInfo.bin");
	}

	std::cout << "Task completed. ";
	system("pause");
	return 0;
}

double GetTime()
{
	clock_t now;
	now = clock();
	return (double)now/CLOCKS_PER_SEC;
}

//Read image
Image* AddImage(const char *filename)
{
	std::cout << "Opening file " << filename << std::endl;
	return readPPM(filename);
}

//Read ppm files into the code
//They need to be in 'binary' format (P6) with no comments in the header
//The first line is the 'P'number - P6 indicates it is a binary file, then the image dimensions and finally the colour range
//This header is then followed by the pixel colour data
//eg:	P6
//		3264 2448
//		255
//Open a .ppm file in notepad++ to see this header (caution: they are large files!)
Image* readPPM(const char *filename)
{
	//Remove this cout to prevent multiple outputs
	std::cout << "Reading image ..." << std::endl;
	std::ifstream ifs;
	ifs.open(filename, std::ios::binary);
	Image* src = new Image(3264, 2448);
	try {
		if (ifs.fail()) {
			throw("Can't open the input file - is it named correctly/is it in the right directory?");
		}
		std::string header;
		int w, h, b;
		ifs >> header;
		if (strcmp(header.c_str(), "P6") != 0) throw("Can't read the input file - is it in binary format (Has P6 in the header)?");
		ifs >> w >> h >> b;
		src->w = w;
		src->h = h;
		//std::cout << w << " " << h << std::endl;
		src->pixels = new Image::Data[w * h]; // this is throw an exception if bad_alloc 
		ifs.ignore(256, '\n'); // skip empty lines in necessary until we get to the binary data 
		unsigned char pix[3]; // read each pixel one by one and convert bytes to floats 
		for (int i = 0; i < w * h; ++i) {
			ifs.read(reinterpret_cast<char *>(pix), 3);
			src->pixels[i].r = pix[0];// / 255.f;
			src->pixels[i].g = pix[1];// / 255.f;
			src->pixels[i].b = pix[2];// / 255.f;
		}
		ifs.close();
	}
	catch (const char *err) {
		fprintf(stderr, "%s\n", err);
		ifs.close();
	}

	//Confirm image read
	//Delete this to prevent multiple lines output
	std::cout << "Image read" << std::endl;
	return src;
}


//Write data out to a ppm file
//Constructs the header as above
void writePPM(const Image &img, const char *filename)
{
	//std::cout << filename << std::endl;
	std::cout << "Writing image ..." << std::endl;
	if (img.w == 0 || img.h == 0) { fprintf(stderr, "Can't save an empty image\n"); return; }
	std::ofstream ofs;
	try {
		ofs.open(filename, std::ios::binary); // need to spec. binary mode for Windows users 
		if (ofs.fail()) throw("Can't open output file");
		ofs << "P6\n" << img.w << " " << img.h << "\n255\n";
		//std::cout << "P6\n" << img.w << " " << img.h << "\n255\n";
		unsigned char r, g, b;
		// loop over each pixel in the image, clamp and convert to byte format
		for (int i = 0; i < img.w * img.h; ++i) {
			r = static_cast<unsigned char>(img.pixels[i].r);
			g = static_cast<unsigned char>(img.pixels[i].g);
			b = static_cast<unsigned char>(img.pixels[i].b);
			ofs << r << g << b;
		}
		ofs.close();
		//Confirm image write
		std::cout << "Saved image to " << filename << std::endl;
	}
	catch (const char *err) {
		fprintf(stderr, "%s\n", err);
		ofs.close();
	}
}