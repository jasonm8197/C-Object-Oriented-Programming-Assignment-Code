#pragma once
//*********************************************
//Image class to hold and allow manipulation of images once read into the code
//from https://www.scratchapixel.com/
//*********************************************
#include <cstdlib> 
#include <cstdio> 
#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

class Image
{
public:
	// Rgb structure, i.e. a pixel 
	struct Rgb
	{
		Rgb() : r(0), g(0), b(0) {}
		Rgb(float c) : r(c), g(c), b(c) {}
		Rgb(float _r, float _g, float _b) : r(_r), g(_g), b(_b) {}
		bool operator != (const Rgb &c) const
		{
			return c.r != r || c.g != g || c.b != b;
		}
		Rgb& operator *= (const Rgb &rgb)
		{
			r *= rgb.r, g *= rgb.g, b *= rgb.b; return *this;
		}
		Rgb& operator += (const Rgb &rgb)
		{
			r += rgb.r, g += rgb.g, b += rgb.b; return *this;
		}
		friend float& operator += (float &f, const Rgb rgb)
		{
			f += (rgb.r + rgb.g + rgb.b) / 3.f; return f;
		}
		float r, g, b;
	};

	/*
		Memory management problems occured when loading images into Rgb struct.
		So I use Data struct which takes uint8_t instead, and convert between them when necessary.
	*/
	struct Data
	{
		Data() : r(0), g(0), b(0) {}
		Data(uint8_t c) : r(c), g(c), b(c) {}
		Data(uint8_t _r, uint8_t _g, uint8_t _b) : r(_r), g(_g), b(_b) {};
		uint8_t r, g, b;
	};

	//Conversion algorithms
	static Rgb DataToRgb(Data& data)
	{
		return Rgb(static_cast<float>(data.r) / 255.f, static_cast<float>(data.g) / 255.f, static_cast<float>(data.b) / 255.f);
	}

	static Data RgbToData(Rgb& data)
	{
		return Data(static_cast<uint8_t>(data.r*255.f), static_cast<uint8_t>(data.g*255.f), static_cast<uint8_t>(data.b*255.f));
	}

	Image() : w(0), h(0), pixels(nullptr) { /* empty image */ }
	Image(const unsigned int &_w, const unsigned int &_h, const Data &c = kBlack) :
		w(_w), h(_h), pixels(NULL)
	{
		pixels = new Data[w * h];
		for (int i = 0; i < w * h; ++i)
			pixels[i] = c;
	}
	const Data& operator [] (const unsigned int &i) const
	{
		return pixels[i];
	}
	Data& operator [] (const unsigned int &i)
	{
		return pixels[i];
	}
	~Image()
	{
		//if (pixels != NULL) delete[] pixels;
		//delete[] pixels;
	}
	unsigned int w, h; // Image resolution 
	Data *pixels; // 1D array of pixels 
	static const Data kBlack, kWhite, kRed, kGreen, kBlue; // Preset colors 

	//Image blending
	static Image* Blend(std::vector<Image*>& images, char* blendType);
	virtual void LogImageInfo(const Image &img, const char* filename);

//Image blending algorithms
private:
	static Rgb GetMean(Rgb* pix, int size);
	static Rgb GetMedian(Rgb* pix, int size);
	static Rgb GetSigmaClip(Rgb* pix, int size);
};