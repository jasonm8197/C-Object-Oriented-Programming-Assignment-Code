#include "Image.h"
const Image::Data Image::kBlack = Image::Data(0);
const Image::Data Image::kWhite = Image::Data(255);
const Image::Data Image::kRed = Image::Data(255, 0, 0);
const Image::Data Image::kGreen = Image::Data(0, 255, 0);
const Image::Data Image::kBlue = Image::Data(0, 0, 255);

//Blend image
Image* Image::Blend(std::vector<Image*>& images, char* blendType)
{
	std::cout << "Blending images..." << std::endl;
	int width, height, aSize;
	width = images[0]->w;
	height = images[0]->h;
	aSize = images.size();

	std::cout << "Applying " << blendType << " algorithm" << std::endl;
	Image* img = new Image(width, height);
	Rgb* pix = new Rgb[aSize];
	for (int i = 0; i < width*height; i++)
	{
		for (int j = 0; j < aSize; j++)
		{
			pix[j] = Image::DataToRgb(images[j]->pixels[i]);
		}
		if (blendType == "mean")img->pixels[i] = Image::RgbToData(Image::GetMean(pix, aSize));
		else if (blendType == "median")img->pixels[i] = Image::RgbToData(Image::GetMedian(pix, aSize));
		else if (blendType == "sigmaclip")img->pixels[i] = Image::RgbToData(Image::GetSigmaClip(pix, aSize));
	}
	return img;
}

//Get the mean
Image::Rgb Image::GetMean(Image::Rgb* pix, int aSize)
{
	Image::Rgb total = Image::Rgb(0);
	for (int i = 0; i < aSize; i++)
	{
		total += pix[i];
	}
	total *= 1.0f / aSize;
	return total;
}

//Get the median
Image::Rgb Image::GetMedian(Image::Rgb* pix, int aSize)
{
	float *reds, *greens, *blues;
	reds = new float[aSize];
	greens = new float[aSize];
	blues = new float[aSize];
	for (int i = 0; i < aSize; i++)
	{
		reds[i] = pix[i].r;
		greens[i] = pix[i].g;
		blues[i] = pix[i].b;
	}
	std::sort(reds, reds + aSize);
	std::sort(greens, greens + aSize);
	std::sort(blues, blues + aSize);
	Image::Rgb ret(reds[aSize / 2], greens[aSize / 2], blues[aSize / 2]);
	delete reds;
	delete greens;
	delete blues;
	return ret;
}

//Sigma clipping
Image::Rgb Image::GetSigmaClip(Image::Rgb* pix, int aSize)
{
	//The algorithm converts the Rgb values into grayscale floats before comparing them
	float* floats_rec = new float[aSize];
	std::vector<float> floats;

	float f, a = 1.0f, m = 0.5f, o = 1.0f, o_old = 1.0f;
	unsigned int iterations = 0;

	float chosen;

	for (int i = 0; i < aSize; i++)
	{
		floats_rec[i] = 0;
		floats_rec[i] += pix[i];
	}

	while (true)
	{
		//Acquire a vector of non-outlier pixels
		floats.clear();
		for (int i = 0; i < aSize; i++)
		{
			f = 0;
			f += pix[i];
			if (f >= m - a*o && f <= m + a*o)
			{
				floats.push_back(f);
			}
		}
		std::sort(floats.begin(), floats.end());
		//Calculate median
		int size = floats.size();
		if (size > 0)
		{
			if (size % 2 == 0)
				m = (floats[size / 2 - 1] + floats[size / 2]) / 2;
			else
				m = floats[size / 2];
		}
		//Calculate standard deviation
		float s1 = 0, s2 = 0;
		for (int i = 0; i < size; i++)
		{
			s1 += (floats[i] * floats[i]) / size;
			s2 += floats[i] / size;
		}
		s2 *= s2;

		o_old = o;
		o = sqrt(s1 - s2);

		//Choose the float in the middle
		if (size > 0)
		{
			chosen = floats[size / 2];
		}

		//Exit conditions
		if (iterations++ > 0)
		{
			if (iterations > 15)
				break;
			else if (abs(o_old - o) < 0.05)
				break;
		}
	}

	Image::Rgb ret;
	for (int i = 0; i < aSize; i++)
	{
		if (floats_rec[i] == chosen)
		{
			ret = pix[i];
		}
	}

	return ret;
}

//Writes log info to .bin file
void Image::LogImageInfo(const Image &img, const char* filename)
{
	std::cout << "Writing image info ..." << std::endl;

	std::ofstream ofs;
	try {
		ofs.open(filename, std::ios::binary); // need to spec. binary mode for Windows users 
		if (ofs.fail()) throw("Can't open output file");
		ofs << "Image width: " << img.w << "\nImage Height: " << img.h << "\n";
		ofs.close();
		//Confirm image write
		std::cout << "Image info written" << std::endl;
	}
	catch (const char *err) {
		fprintf(stderr, "%s\n", err);
		ofs.close();
	}
}